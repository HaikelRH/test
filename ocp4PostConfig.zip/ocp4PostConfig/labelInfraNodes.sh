oc label node/infra1.scbocpprod.scb.local node-role.kubernetes.io/infra=
oc label node/infra2.scbocpprod.scb.local node-role.kubernetes.io/infra=
oc label node/infra2.scbocpprod.scb.local node-role.kubernetes.io/worker-
oc label node/infra1.scbocpprod.scb.local node-role.kubernetes.io/worker-

